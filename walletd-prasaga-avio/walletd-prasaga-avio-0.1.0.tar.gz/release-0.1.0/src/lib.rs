//! # WalletD Prasaga Avio SDK
//! 
//! A Rust SDK for integrating with the Prasaga Avio blockchain's object-oriented architecture.
//! 
//! ## Features
//! 
//! - **Multi-network support**: Mainnet, Testnet, and Mocknet configurations
//! - **Ed25519 cryptography**: Secure key generation and transaction signing
//! - **XBOM serialization**: Native support for Prasaga's object model
//! - **PSA tokens**: Programmable Smart Asset management
//! 
//! ## Quick Start
//! 
//! ```rust,no_run
//! use walletd_prasaga_avio::{PrasagaAvioClient, Network};
//! 
//! # async fn example() -> Result<(), Box<dyn std::error::Error>> {
//! // Connect to testnet
//! let client = PrasagaAvioClient::testnet().await?;
//! 
//! // Check network health
//! let healthy = client.health_check().await?;
//! # Ok(())
//! # }
//! ```

#![doc(html_logo_url = "https://prasaga.com/logo.png")]
#![doc(html_favicon_url = "https://prasaga.com/favicon.ico")]

pub mod network;
pub mod keys;
pub mod transaction;
pub mod assets;
pub mod indexer;
pub mod types;
pub mod utils;
pub mod xbom;
pub mod psa;

#[cfg(feature = "testing")]
pub mod testing;

// Re-exports
pub use types::*;
pub use network::client::PrasagaAvioClient;
pub use network::config::{Network, NetworkConfig};
pub use keys::keypair::PrasagaAvioKeypair;
pub use transaction::builder::{TransactionBuilder, Operation};
pub use transaction::signer::{TransactionSigner, SignedTransaction};

/// Library version
pub const VERSION: &str = env!("CARGO_PKG_VERSION");

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_version() {
        assert_eq!(VERSION, "0.1.0");
    }
}
