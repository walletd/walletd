//! Blockchain indexing and event monitoring

#[derive(Debug, Clone)]
pub struct Indexer {
    // Placeholder for indexer
}

impl Indexer {
    pub fn new() -> Self {
        Self {}
    }
}

impl Default for Indexer {
    fn default() -> Self {
        Self::new()
    }
}
